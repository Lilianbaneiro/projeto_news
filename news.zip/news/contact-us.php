<?php
error_reporting(0);
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit'])) {
   
  $nome =( $_POST['name']);
  $email = ( $_POST['e-mail']);
  $comentario = ( $_POST['comentario']);



//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
  //Server settings
  //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
  $mail->isSMTP();                                            //Send using SMTP
  $mail->Host       = 'smtpi.uni5.net';                       //Set the SMTP server to send through
  $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
  $mail->Username   = 'mail@jumbo.com.br';                    //SMTP username
  $mail->Password   = 'Senac#12';                             //SMTP password
  $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         //Enable implicit TLS encryption
  $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

  //Recipients
  $mail->setFrom('mail@jumbo.com.br', 'Mailer');
  $mail->addAddress('lilianbaneiro26@gmail.com', 'Lilian');   //Add a recipient
  //$mail->addAddress('ellen@example.com');                   //Name is optional
  //$mail->addReplyTo('info@example.com', 'Information');
  //$mail->addCC('cc@example.com');
  //$mail->addBCC('bcc@example.com');

  //Attachments
  //$mail->addAttachment('/var/tmp/file.tar.gz');             //Add attachments
  //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');        //Optional name

  //Content
  $mail->isHTML(true);                                        //Set email format to HTML
  $mail->Subject = 'Mensagem enviada do formulário [FORM]';
  $mail->Body    = $comentario;
  $mail->AltBody = $comentario;
  $mensage = $_POST['mensagem'];
  $mail->send();
  echo 'Messagem enviada';
} catch (Exception $e) {
  echo "Erro ao enviar mensagem. Mailer Error: {$mail->ErrorInfo}";
}
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Senac">
  <meta name="author" content="Senac">
  <title>Portal Notícias | Contato</title>
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">
</head>

<body>
  <!-- Navigation -->
  <?php include('includes/header.php'); ?>
  <!-- Page Content -->
  <div class="container">
    <h1 class="mt-4 mb-3">Contate-nos</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="index.php">Home</a>
      </li>
      <li class="breadcrumb-item active">Contato</li>
    </ol>
    <!-- Intro Content -->
    <div class="row">
        <div class="col-lg-12">
        <form class="comentario" method="post"> <h2 class="h2">Comentario</h2>
            <label>Nome:</label>
            <input type="text" name="name" required />
            <br><br>
            <label>Email:</label>
            <input type="email" name="e-mail" required />
            <br><br>
            <label>Comentario:</label>
            <textarea name="comentario"></textarea>
            <br><br>
            <button type="enviar" name="submit">Enviar</button>

        </form>
        </div>
      </div>
    <!-- /.row -->
  </div>
  <!-- /.container -->
  <!-- Footer -->
  <?php include('includes/footer.php'); ?>
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>