<?php
class Api {
    public readondly int $num_rows;
    private $conexao;
    private function Connection() {
        $this->conexao = new mysqli("localhost", "root", "", "news");
    }
    public function Get(int $id) {
        $this->Connection();
        $result = $this->conexao->query('SELECT posts.id as pid, category.CategoryName as category, posts.PostTitle as posttitle, posts.CategoryId as cid,  posts.UpdationDate, CONCAT("admin/postimages/", posts.PostImage) as postimage FROM posts LEFT JOIN category ON category.id = posts.CategoryId WHERE posts.id= ' . $id . ' AND  posts.Is_Active = 1');
        $itens = $result->fetch_all(MYSQLI_ASSOC);
        if(count($itens) > 0) return json_encode($itens[0], JSON_UNESCAPED_SLASHES);
        else return json_encode(['error' => 'Notícia não existente']);

    }
}
$api = new Api();
echo isset($_GET['pid']) && intval($_GET['pid']) > 0 ? $api->Get($_GET['pid']) : json_encode(['error' => 'Notícia não existente']);
echo $api->Get();
?>