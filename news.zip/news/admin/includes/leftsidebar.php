<div class="left side-menu">
   <div class="sidebar-inner slimscrollleft">
      <!--- Sidemenu -->
      <div id="sidebar-menu">
         <ul>
            <li class="menu-title">Navegação</li>
            <li class="has_sub">
               <a href="manage-categories.php" class="waves-effect"><i class="mdi mdi-view-dashboard"></i> <span> Editorias </span> </a>
            </li>
            <li class="has_sub">
               <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Notícias </span> <span class="menu-arrow"></span></a>
               <ul class="list-unstyled">
                  <li><a href="add-post.php">Adicionar Notícias</a></li>
                  <li><a href="manage-posts.php">Listar Notícias</a></li>
                  <li><a href="trash-posts.php">Notícias apagadas</a></li>
               </ul>
            </li>
            <li class="has_sub">
               <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-format-list-bulleted"></i> <span> Comentários </span> <span class="menu-arrow"></span></a>
               <ul class="list-unstyled">
                  <li><a href="unapprove-comment.php">Aguardando aprovação</a></li>
                  <li><a href="manage-comments.php">Comentários aprovados</a></li>
               </ul>
            </li>
         </ul>
      </div>
      <!-- Sidebar -->
      <div class="clearfix"></div>
   </div>
   <!-- Sidebar -left -->
</div>